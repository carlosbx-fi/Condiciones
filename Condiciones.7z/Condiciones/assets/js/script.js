//alert("Hola soy un archivo JS")

img = document.querySelector("img");

mostrarBorder = false;

img.addEventListener("click", function(){

    if(!mostrarBorder){
        img.style.border = "solid red 2px";
        mostrarBorder = true;
    }
    else{
        img.style.border = "none";
        mostrarBorder = false;
    }
});

n1 = document.querySelector("#ip-1");
n2 = document.querySelector("#ip-2");
n3 = document.querySelector("#ip-3");

button = document.querySelector("button");

button.addEventListener("click", function (){
    
suma = Number(n1.value) + Number(n2.value) + Number(n3.value)

parrafo = document.querySelector("#resultado")

if (suma <= 10) {
    parrafo.innerHTML = "llevas " + suma + " stickers";
} else {
    parrafo.innerHTML = "llevas demasiados stickers";
}
});
